document.addEventListener('DOMContentLoaded', function() {
    const calendarDates = document.getElementById('calendarDates');
    const monthYearDisplay = document.getElementById('monthYearDisplay');
    const prevMonthButton = document.getElementById('prevMonth');
    const nextMonthButton = document.getElementById('nextMonth');
    const selectedDateDisplay = document.getElementById('selectedDate');
    const todoInput = document.getElementById('todoInput');
    const addTodoButton = document.getElementById('addTodoButton');
    const todoList = document.getElementById('todoList');

    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();
    let selectedDate = null;
    let todos = {};

    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];

    function renderCalendar(month, year) {
        calendarDates.innerHTML = '';
        monthYearDisplay.textContent = months[month] + ' ' + year;
        
        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Fill in the days from the previous month
        for (let i = 0; i < firstDayOfMonth; i++) {
            const emptyDiv = document.createElement('div');
            calendarDates.appendChild(emptyDiv);
        }

        // Fill in the days of the current month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayDiv = document.createElement('div');
            dayDiv.textContent = day;
            dayDiv.addEventListener('click', (function(day, month, year) {
                return function() {
                    selectedDate = new Date(year, month, day);
                    selectedDateDisplay.textContent = selectedDate.toDateString();
                    renderTodoList();
                };
            })(day, month, year));
            calendarDates.appendChild(dayDiv);
        }
    }

    function renderTodoList() {
        todoList.innerHTML = '';
        if (!selectedDate) return;
        const dateKey = selectedDate.toDateString();
        const dateTodos = todos[dateKey] || [];

        dateTodos.forEach((todo, index) => {
            const li = document.createElement('li');
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = `todo-${dateKey}-${index}`;
            const label = document.createElement('label');
            label.setAttribute('for', `todo-${dateKey}-${index}`);
            label.textContent = todo;
            li.appendChild(checkbox);
            li.appendChild(label);
            todoList.appendChild(li);
        });
    }

    addTodoButton.addEventListener('click', function() {
        if (!selectedDate) {
            alert('Please select a date first');
            return;
        }
        const task = todoInput.value.trim();
        if (task) {
            const dateKey = selectedDate.toDateString();
            if (!todos[dateKey]) {
                todos[dateKey] = [];
            }
            todos[dateKey].push(task);
            todoInput.value = '';
            renderTodoList();
        } else {
            alert('Please enter a task');
        }
    });

    prevMonthButton.addEventListener('click', function() {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        renderCalendar(currentMonth, currentYear);
    });

    nextMonthButton.addEventListener('click', function() {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        renderCalendar(currentMonth, currentYear);
    });

    renderCalendar(currentMonth, currentYear);
});